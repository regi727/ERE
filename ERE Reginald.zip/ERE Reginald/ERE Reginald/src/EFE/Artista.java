package EFE;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

/**
 *
 * @author louis
 */
public class Artista {

    private int id_artista;
    private String nombre;
    private String apellido;
    private String edad;

    
    public int getId_artista() {
        return id_artista;

    }

    public void setId_artista(int id_artista) {
        this.id_artista = id_artista;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String apellido() {
        return apellido;
    }

    public void setapellido(String nombre) {
        this.apellido = apellido;
    }

    public String getedad() {
        return edad;
    }

    public void setedad(String nombre) {
        this.edad = edad;
    }
    public String toString(){
        return this.nombre;
    
    }

    
}
