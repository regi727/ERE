/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EFE;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author louis
 */
public class Conexion {
    public static final String URL = "jdbc:derby://localhost:1527/Examen";
    public static final String usuario = "Reginald";
    public static final String contrasena = "1234";
    
      public Connection getConnection() {
        Connection conexion = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conexion = (Connection) DriverManager.getConnection(URL, usuario, contrasena);

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }

        return conexion;

    }
}
