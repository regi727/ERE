/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EFE;

import java.util.Vector;

/**
 *
 * @author louis
 */
public class Disenador {
    private String id_disenador;
    private String nombre;
    private String apellido;
    private String edad;
    
    public Disenador(String id_disenador,String nombre,String apellido,String edad){
        this.id_disenador = id_disenador;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;

    }
      public String getId_disenador(){
        return id_disenador;
        
        }
      public void setId_artista(String id_profesor) {
        this.id_disenador = id_disenador;
    }
      public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String apellido() {
        return apellido;
    }

    public void setapeliido(String nombre) {
        this.apellido = apellido;
    }
    public String getedad() {
        return edad;
    }

    public void setedad(String nombre) {
        this.edad = edad;
    }
    
}
