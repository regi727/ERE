package EFE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author louis
 */
public class CargarDatos extends javax.swing.JFrame {

    public static final String URL = "jdbc:derby://localhost:1527/Examen";
    public static final String usuario = "Reginald";
    public static final String contrasena = "1234";
    PreparedStatement ps;
    ResultSet rs;

    public Connection getConnection() {
        Connection conexion = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conexion = (Connection) DriverManager.getConnection(URL, usuario, contrasena);

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }

        return conexion;

    }

    public void limpiarText() {
        TextBuscar.setText(null);
        textId.setText(null);
        textApellido.setText(null);
        textNombre.setText(null);
        textEdad.setText(null);

    }


    /**
     * Creates new form CargarDatos
     */
    public CargarDatos() {
        initComponents();

        ComboBoxDisenador.addItem("Seleccionar nombre");

        try {
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();

            ps = conexion.prepareStatement(" Select NOMBRE from Disenador");
            rs = ps.executeQuery();
            while (rs.next()) {
                ComboBoxDisenador.addItem(rs.getString("NOMBRE"));
            }
            rs.close();

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }
        ComboBoxEditor.addItem("Seleccionar nombre");

        try {
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();

            ps = conexion.prepareStatement(" Select NOMBRE from Editor");
            rs = ps.executeQuery();
            while (rs.next()) {
                ComboBoxEditor.addItem(rs.getString("NOMBRE"));
            }
            rs.close();

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }
        ComboBoxArtista.addItem("Seleccionar nombre");
        try {
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();

            ps = conexion.prepareStatement(" Select NOMBRE from Artista");
            rs = ps.executeQuery();
            
            while (rs.next()) {
                ComboBoxArtista.addItem(rs.getString("NOMBRE"));
            }
            rs.close();
            rs.close();

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }

    }
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        ComboBoxDisenador = new javax.swing.JComboBox<>();
        labelDisenador = new javax.swing.JLabel();
        ComboBoxEditor = new javax.swing.JComboBox<>();
        labelEditor = new javax.swing.JLabel();
        ComboBoxArtista = new javax.swing.JComboBox<>();
        labelArtista = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        btnCargarJuegos = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaCargarJUEGOS = new javax.swing.JTable();
        btnBuscarArtista = new javax.swing.JButton();
        TextBuscar = new javax.swing.JTextField();
        textId = new javax.swing.JTextField();
        textNombre = new javax.swing.JTextField();
        textApellido = new javax.swing.JTextField();
        textEdad = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        labelApellido = new javax.swing.JLabel();
        labelEdad = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnlimpiar = new javax.swing.JButton();
        btnModificarArt = new javax.swing.JButton();
        btnBuscarDisenador = new javax.swing.JButton();
        btnBuscarEditor = new javax.swing.JButton();
        btnModificarEd = new javax.swing.JButton();
        btnModificarDis = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelDisenador.setText("Disenador");

        labelEditor.setText("Editor");

        labelArtista.setText("Artista");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_ARTISTA", "NOMBRE", "APELLIDO", "EDAD"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 387, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(labelDisenador)
                            .addComponent(labelEditor)
                            .addComponent(labelArtista)
                            .addComponent(ComboBoxDisenador, 0, 226, Short.MAX_VALUE)
                            .addComponent(ComboBoxEditor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBoxArtista, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(labelDisenador)
                .addGap(18, 18, 18)
                .addComponent(ComboBoxDisenador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(labelEditor)
                .addGap(24, 24, 24)
                .addComponent(ComboBoxEditor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(labelArtista)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ComboBoxArtista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        btnCargarJuegos.setText("Cargar Juegos");
        btnCargarJuegos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarJuegosActionPerformed(evt);
            }
        });

        tablaCargarJUEGOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_JUEGO", "NOMBRE_JUEGO"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tablaCargarJUEGOS);

        btnBuscarArtista.setText("Buscar Artista");
        btnBuscarArtista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarArtistaActionPerformed(evt);
            }
        });

        jLabel1.setText("NOMBRE");

        labelApellido.setText("APELLIDO");

        labelEdad.setText("EDAD");

        jLabel2.setText("ID");

        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });

        btnModificarArt.setText("Modificar Art");
        btnModificarArt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarArtActionPerformed(evt);
            }
        });

        btnBuscarDisenador.setText("Buscar Disenador");
        btnBuscarDisenador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarDisenadorActionPerformed(evt);
            }
        });

        btnBuscarEditor.setText("Buscar Editor");
        btnBuscarEditor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarEditorActionPerformed(evt);
            }
        });

        btnModificarEd.setText("Modificar Ed");
        btnModificarEd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarEdActionPerformed(evt);
            }
        });

        btnModificarDis.setText("Modificar Dis");
        btnModificarDis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarDisActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnlimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCargarJuegos)
                            .addComponent(btnModificarArt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnModificarEd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificarDis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnBuscarDisenador, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscarArtista, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscarEditor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(TextBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(labelApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(36, 36, 36))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(textEdad, javax.swing.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
                            .addComponent(textApellido)
                            .addComponent(textId)
                            .addComponent(textNombre))
                        .addGap(45, 45, 45))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(btnBuscarArtista)
                            .addComponent(TextBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(btnBuscarDisenador))))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelApellido)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(btnBuscarEditor)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelEdad))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 467, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnlimpiar)
                        .addGap(33, 33, 33)
                        .addComponent(btnCargarJuegos)
                        .addGap(47, 47, 47)
                        .addComponent(btnModificarArt)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificarEd)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificarDis)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCargarJuegosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarJuegosActionPerformed
        DefaultTableModel modeloTabla = new DefaultTableModel();
        tablaCargarJUEGOS.setModel(modeloTabla);

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Conexion con = new Conexion();
            Connection conexion = con.getConnection();

            ps = conexion.prepareStatement("Select ID_JUEGO,NOMBRE_JUEGO from JUEGOS");
            rs = ps.executeQuery();

            modeloTabla.addColumn(" ID_JUEGO ");
            modeloTabla.addColumn(" NOMBRE_JUEGO ");

            while (rs.next()) {
                Object fila[] = new Object[2];
                for (int i = 0; i < 2; i++) {
                    fila[i] = rs.getObject(i + 1);

                }
                modeloTabla.addRow(fila);

            }

        } catch (Exception ex) {
            System.err.println("Err," + ex);

        }

    }//GEN-LAST:event_btnCargarJuegosActionPerformed

    private void btnBuscarArtistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarArtistaActionPerformed
        Connection conexion = null;

        try {
            conexion = getConnection();
            ps = conexion.prepareStatement("Select * from ARTISTA where ID_ARTISTA = ?");
            ps.setString(1, TextBuscar.getText());
            rs = ps.executeQuery();

            if (rs.next()) {
                textId.setText(rs.getString("ID_ARTISTA"));
                textNombre.setText(rs.getString("NOMBRE"));
                textApellido.setText(rs.getString("APELLIDO"));
                textEdad.setText(rs.getString("EDAD"));

            } else {
                JOptionPane.showMessageDialog(null, " La persona no existe");

            }
            conexion.close();

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }
        
        
        
    }//GEN-LAST:event_btnBuscarArtistaActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        limpiarText();
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btnModificarArtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarArtActionPerformed
        Connection conexion = null;
        conexion = getConnection();

        try {
            ps = conexion.prepareStatement("update ARTISTA set ID_ARTISTA =?,NOMBRE =?,APELLIDO =?,EDAD =?");
            ps.setInt(1, Integer.parseInt(textId.getText()));
            ps.setString(2, textNombre.getText());
            ps.setString(3, textApellido.getText());
            ps.setInt(4, Integer.parseInt(textEdad.getText()));

            int resultado = ps.executeUpdate();
            if (resultado > 0) {

                JOptionPane.showMessageDialog(null, " Registro modificado ");
                limpiarText();
            }
            JOptionPane.showMessageDialog(null, " Error al modificar ");
            limpiarText();
            
            conexion.close();

        } catch (Exception ex) {
            System.err.print("Error,"+ex);

        }
    }//GEN-LAST:event_btnModificarArtActionPerformed

    private void btnBuscarDisenadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarDisenadorActionPerformed
       Connection conexion = null;
       try {
            conexion = getConnection();
            ps = conexion.prepareStatement("Select * from DISENADOR where ID_DISENADOR = ?");
            ps.setString(1, TextBuscar.getText());
            rs = ps.executeQuery();

            if (rs.next()) {
                textId.setText(rs.getString("ID_DISENADOR"));
                textNombre.setText(rs.getString("NOMBRE"));
                textApellido.setText(rs.getString("APELLIDO"));
                textEdad.setText(rs.getString("EDAD"));

            } else {
                JOptionPane.showMessageDialog(null, " La persona no existe");

            }
            conexion.close();

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }
    }//GEN-LAST:event_btnBuscarDisenadorActionPerformed

    private void btnBuscarEditorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarEditorActionPerformed
        Connection conexion = null;
        
        try {
            conexion = getConnection();
            ps = conexion.prepareStatement("Select * from Editor where ID_EDITOR = ?");
            ps.setString(1, TextBuscar.getText());
            rs = ps.executeQuery();

            if (rs.next()) {
                textId.setText(rs.getString("ID_EDITOR"));
                textNombre.setText(rs.getString("NOMBRE"));
                textApellido.setText(rs.getString("APELLIDO"));
                textEdad.setText(rs.getString("EDAD"));

            } else {
                JOptionPane.showMessageDialog(null, " La persona no existe");

            }
            conexion.close();

        } catch (Exception ex) {
            System.err.println("Error," + ex);

        }
    }//GEN-LAST:event_btnBuscarEditorActionPerformed

    private void btnModificarEdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarEdActionPerformed
        Connection conexion = null;
        conexion = getConnection();

        try {
            ps = conexion.prepareStatement("update EDITOR set ID_EDITOR =?,NOMBRE =?,APELLIDO =?,EDAD =?");
            ps.setInt(1, Integer.parseInt(textId.getText()));
            ps.setString(2, textNombre.getText());
            ps.setString(3, textApellido.getText());
            ps.setInt(4, Integer.parseInt(textEdad.getText()));

            int resultado = ps.executeUpdate();
            if (resultado > 0) {

                JOptionPane.showMessageDialog(null, " Registro modificado ");
                limpiarText();
            }
            JOptionPane.showMessageDialog(null, " Error al modificar ");
            limpiarText();
            
            conexion.close();

        } catch (Exception ex) {
            System.err.print("Error,"+ex);

        }
    }//GEN-LAST:event_btnModificarEdActionPerformed

    private void btnModificarDisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarDisActionPerformed
        Connection conexion = null;
        conexion = getConnection();

        try {
            ps = conexion.prepareStatement("update DISENADOR set ID_DISENADOR =?,NOMBRE =?,APELLIDO =?,EDAD =?");
            ps.setInt(1, Integer.parseInt(textId.getText()));
            ps.setString(2, textNombre.getText());
            ps.setString(3, textApellido.getText());
            ps.setInt(4, Integer.parseInt(textEdad.getText()));

            int resultado = ps.executeUpdate();
            if (resultado > 0) {

                JOptionPane.showMessageDialog(null, " Registro modificado ");
                limpiarText();
            }
            JOptionPane.showMessageDialog(null, " Error al modificar ");
            limpiarText();
            
            conexion.close();

        } catch (Exception ex) {
            System.err.print("Error,"+ex);

        }
    }//GEN-LAST:event_btnModificarDisActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CargarDatos.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CargarDatos.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CargarDatos.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CargarDatos.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CargarDatos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxArtista;
    private javax.swing.JComboBox<String> ComboBoxDisenador;
    private javax.swing.JComboBox<String> ComboBoxEditor;
    private javax.swing.JTextField TextBuscar;
    private javax.swing.JButton btnBuscarArtista;
    private javax.swing.JButton btnBuscarDisenador;
    private javax.swing.JButton btnBuscarEditor;
    private javax.swing.JButton btnCargarJuegos;
    private javax.swing.JButton btnModificarArt;
    private javax.swing.JButton btnModificarDis;
    private javax.swing.JButton btnModificarEd;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelApellido;
    private javax.swing.JLabel labelArtista;
    private javax.swing.JLabel labelDisenador;
    private javax.swing.JLabel labelEdad;
    private javax.swing.JLabel labelEditor;
    private javax.swing.JTable tablaCargarJUEGOS;
    private javax.swing.JTextField textApellido;
    private javax.swing.JTextField textEdad;
    private javax.swing.JTextField textId;
    private javax.swing.JTextField textNombre;
    // End of variables declaration//GEN-END:variables

}
